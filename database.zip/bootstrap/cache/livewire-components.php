<?php return array (
  'add-comment' => 'App\\Http\\Livewire\\AddComment',
  'blog-details' => 'App\\Http\\Livewire\\BlogDetails',
  'category-details' => 'App\\Http\\Livewire\\CategoryDetails',
  'main-blogs' => 'App\\Http\\Livewire\\MainBlogs',
  'test' => 'App\\Http\\Livewire\\Test',
);