<footer style="background: #046738; color: white;">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-3">
                <h3>Ku bindi bisobanuro</h3>
                <a href="tel:+250781101010" id="phone">+250 781 101 010</a>
                <a href="tel:+250726668344" id="phone">+250 726 668 344</a>

                <a href="mailto:info@tembera250.com" id="email_footer">info@tembera250.com</a>
            </div>
            <div class="col-md-2 col-sm-3">
                <h3>Abo turibo</h3>
                <ul>
                    <li><a href="#">Abo turibo</a>
                    </li>

                </ul>
            </div>
            <div class="col-md-4 col-sm-6">
                <h3>Twitter feed</h3>
                <div class="latest-tweets" data-number="10" data-username="boysonserge250" data-mode="fade" data-pager="false" data-nextselector=".tweets-next" data-prevselector=".tweets-prev" data-adaptiveheight="true">

                </div>
                <div class="tweet-control">
                    <div class="tweets-prev"></div>
                    <div class="tweets-next"></div>
                </div>

            </div>
            <div class="col-md-3 col-sm-12">
                <h3>Guma kumurongo</h3>
                <div id="message-newsletter_2">
                </div>
                <form method="post" action="assets/newsletter.php" name="newsletter_2" id="newsletter_2">
                    <div class="form-group">
                        <input name="email_newsletter_2" id="email_newsletter_2" type="email" value="" placeholder="Your email" class="form-control">
                    </div>
                    <input type="submit" value="Emeza" class="btn_1" id="submit-newsletter_2">
                </form>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-sm-8">

                <span id="copy" style="color: white;">© Tembera250</span>
            </div>
            <div class="col-sm-4" id="social_footer">
                <ul>
                    <li><a target="__blank" href=""><i class="icon-facebook"></i></a>
                    </li>
                    <li><a target="__blank" href=""><i class="icon-linkedin-2"></i></a>
                    </li>
                    <li><a target="__blank" href=""><i class="icon-google"></i></a>
                    </li>
                    <li><a target="__blank" href=""><i class="icon-instagram"></i></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>
