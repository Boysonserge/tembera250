<?php if(config('filament.layout.footer.should_show_logo')): ?>
    <div class="flex items-center justify-center filament-footer">
        @tembera250
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\Boyson Graphix\Pictures\sites\tembera250\vendor\filament\filament\src\/../resources/views/components/footer.blade.php ENDPATH**/ ?>