<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="The best tourism company in Kigali Rwanda">
    <meta name="author" content="Braidos">
    <title>TEMBERA250 RWANDA | We are sports and leisure</title>

    <!-- Favicons-->
    <link rel="shortcut icon" href="<?php echo e(asset('images/fav.png')); ?>" type="image/x-icon">

    <!-- GOOGLE WEB FONT -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700|Satisfy" rel="stylesheet">

    <!-- BASE CSS -->
    <link href="<?php echo e(asset('css/animate.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/responsive.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/menu.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/icon_fonts/css/all_icons.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body>
<?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="parallax_window_in" data-parallax="scroll" data-image-src="<?php echo e(asset('img/sub_header_list_museum.jpg')); ?>" data-natural-width="1400" data-natural-height="470">
    <div id="sub_content_in">
        <div id="animate_intro">
            <h1>Amakuru ari muri "<?php echo e($catName); ?>"</h1>
        </div>
    </div>
</section>

<section class="wrapper">
    <div class="divider_border_gray"></div>

    <!-- End filters -->

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('category-details',['slug'=>$slug])->html();
} elseif ($_instance->childHasBeenRendered('AZ9fjL0')) {
    $componentId = $_instance->getRenderedChildComponentId('AZ9fjL0');
    $componentTag = $_instance->getRenderedChildComponentTagName('AZ9fjL0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AZ9fjL0');
} else {
    $response = \Livewire\Livewire::mount('category-details',['slug'=>$slug]);
    $html = $response->html();
    $_instance->logRenderedChild('AZ9fjL0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>;
    <!-- End container -->
</section>
<div class="container margin_60">
    <div class="banner">
        <h3>Wakoze kuba hano</h3>
        <a href="#" class="btn_1 white">Menya byinci kuritwe</a>
    </div>
    <!-- end banner -->
</div>
<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- COMMON SCRIPTS -->
<script src="<?php echo e(asset('js/jquery-2.2.4.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/common_scripts_min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.tweet.min.js')); ?>"></script>
<?php echo \Livewire\Livewire::scripts(); ?>


</body>

</html>


<?php /**PATH C:\Users\Boyson Graphix\Pictures\sites\tembera250\resources\views/category.blade.php ENDPATH**/ ?>