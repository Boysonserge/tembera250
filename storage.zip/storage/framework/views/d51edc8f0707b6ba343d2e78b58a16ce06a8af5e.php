<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="The best tourism company in Kigali Rwanda">
    <meta name="author" content="Braidos">
    <title>TEMBERA250 RWANDA | We are sports and leisure</title>
    <meta name="title" content="TEMBERA250 RWANDA | We are sports and leisure">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo e(url()->full()); ?>">
    <meta property="og:title" content="<?php echo e($blogSelected->blogTitle); ?>">
    <meta property="og:description" content="<?php echo e($blogSelected->blogSummary); ?>">
    <meta property="og:image" content="<?php echo e(asset('storage/'.$blogSelected->mainPhoto)); ?>">

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="<?php echo e(url()->full()); ?>">
    <meta property="twitter:title" content="TEMBERA250 RWANDA | We are sports and leisure">
    <meta property="twitter:description" content="The best tourism company in Kigali Rwanda">
    <meta property="twitter:image" content="<?php echo e(asset('storage/'.$blogSelected->mainPhoto)); ?>">

    <!-- Favicons-->
    <link rel="shortcut icon" href="<?php echo e(asset('images/fav.png')); ?>" type="image/x-icon">

    <!-- GOOGLE WEB FONT -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700|Satisfy" rel="stylesheet">

    <!-- BASE CSS -->
    <link href="<?php echo e(asset('css/animate.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/responsive.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/menu.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/icon_fonts/css/all_icons.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">

    <?php echo \Livewire\Livewire::styles(); ?>




</head>

<body>
<?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="parallax_window_in" data-parallax="scroll" data-image-src="<?php echo e(asset('img/sub_header_about.jpg')); ?>"
         data-natural-width="1400" data-natural-height="470">
    <div id="sub_content_in">
        <div id="animate_intro">
            <h1><?php echo e($blogSelected->blogTitle); ?></h1>
            <p><?php echo e($blogSelected->blogSummary); ?></p>

        </div>
    </div>
</section>
<section class="wrapper">
    <div class="divider_border"></div>

    <div class="container">

        <div class="row">
            <div class="col-md-9 add_bottom_15">
                <div class="bloglist singlepost">
                    <div class="wow fadeIn">
                        <img alt="" class="img-responsive img-thumbnail" src="<?php echo e(asset('storage/'.$blogSelected->mainPhoto)); ?>">

                        <div class="singlepost_title">
                            <h4><?php echo e($blogSelected->blogTitle); ?></h4>
                        </div>

                        <div class="postmeta">

                            <ul class="list-inline">
                                <li><a href="#"><i class="icon_folder-alt"></i> <?php echo e($blogSelected->categories->categoryName); ?></a>
                                </li>
                                <li><a href="#"><i class="icon_clock_alt"></i>
                                        <?php echo e($blogSelected->created_at->format('Y-m-d')); ?></a>
                                </li>
                                <li><a href="#"><i class="icon_pencil-edit"></i> <?php echo e($blogSelected->editors->name); ?></a>
                                </li>


                                <li><a href="#"><i class="icon-eye"></i> <?php echo e($blogSelected->views); ?></a>
                                </li>
                            </ul>
                        </div>

                        <div class="post-contnt">


                            <?php echo $blogSelected->mainStory; ?>

                        </div>
                        <!-- end post -->

                    </div>



                    <div class="post-footer">
                        <div class="pull-left">
                            <a href="#" class="readmore">View all posts [..]</a>
                        </div>
                        <div class="pull-right">
                            <ul class="social list-inline">
                                <li><a target="__blank" href="<?php echo e($facebook); ?>"><i class="icon-facebook"></i></a>
                                </li>
                                <li><a target="__blank" href="<?php echo e($twitter); ?>"><i class="icon-twitter"></i></a>
                                </li>
                                <li><a target="__blank" href="#"><i class="icon-instagram"></i></a>
                            </ul>
                        </div>
                    </div>



                </div>
                <!-- end single-post -->

                <div class="blog-list row">
                    <div class="col-md-12">
                        <hr>
                        <div class="comments">
                            <div class="widget-title">
                                <h4><i class="icon_comment_alt"></i>(<?php echo e(count($comments)); ?>) Comments - About this article </h4>
                            </div>


                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="media">
                                <div class="media-left">
                                    <a href="#"><img class="media-object" src="<?php echo e(asset('img/team_01.jpg')); ?>" alt="">
                                    </a>

                                </div>

                                    <div class="media-body">
                                        <h4 class="media-heading"><?php echo e($cmt->name); ?>

                                            <span class="time-comment">
													<small><?php echo e($cmt->created_at->format('Y-m-d')); ?></small>
													<a class="comment-reply" href="#"><small>Reply</small></a>
												</span><!-- end time-comment -->
                                        </h4>
                                        <p><?php echo e($cmt->comment); ?></p>
                                    </div>


                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        <!-- end media -->
                        </div>

                        <hr>

                        <h4>Leave a Comment</h4>


                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-comment',['blogId'=>$blogSelected->id])->html();
} elseif ($_instance->childHasBeenRendered('fK50uz0')) {
    $componentId = $_instance->getRenderedChildComponentId('fK50uz0');
    $componentTag = $_instance->getRenderedChildComponentTagName('fK50uz0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fK50uz0');
} else {
    $response = \Livewire\Livewire::mount('add-comment',['blogId'=>$blogSelected->id]);
    $html = $response->html();
    $_instance->logRenderedChild('fK50uz0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                    <!-- end col-->
                </div>
                <!-- end blog-list -->
            </div>


            <aside id="sidebar" class="col-md-3">

                <!-- end widget -->

                <div class="widget">
                    <div class="widget-title">
                        <h4>Recent Posts</h4>
                    </div>

                    <ul class="comments-list">
                        <?php $__currentLoopData = $recents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <div class="alignleft">
                                    <img src="<?php echo e(asset('storage/'.$rec->mainPhoto)); ?>" alt="">
                                </div>
                                <h3><a href="" title=""><?php echo e(Illuminate\Support\Str::of($rec->blogTitle)->limit(20)); ?></a></h3>
                                <small><?php echo e($rec->created_at->format('Y-m-d')); ?></small>

                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>







                    </ul>
                    <!-- end blog list -->
                </div>
                <!-- end widget -->
            </aside>
            <!-- end sidebar -->
        </div>
        <!-- end row -->
    </div>

    <!-- End container -->
</section>

<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- COMMON SCRIPTS -->
<script src="<?php echo e(asset('js/jquery-2.2.4.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/common_scripts_min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.tweet.min.js')); ?>"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha256-4+XzXVhsDmqanXGHaHvgh1gMQKX40OUvDEBTu8JcmNs=" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('js/share.js')); ?>"></script>

<?php echo \Livewire\Livewire::scripts(); ?>


</body>

</html>


<?php /**PATH C:\Users\Boyson Graphix\Pictures\sites\tembera250\resources\views/blog.blade.php ENDPATH**/ ?>