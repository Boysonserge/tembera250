<h2 <?php echo e($attributes->class(['text-xl font-semibold tracking-tight filament-card-heading'])); ?>>
    <?php echo e($slot); ?>

</h2>
<?php /**PATH C:\Users\Boyson Graphix\Pictures\sites\tembera250\vendor\filament\filament\src\/../resources/views/components/card/heading.blade.php ENDPATH**/ ?>